package address_book;

public interface AddressEntry {

}
