package address_book;

public class AddressEntries {
	

//}
public void setlastName(String lastName) {
	//this.lastName = lastName;
}
//public String getPhoneNumber() {
	//return phoneNumber;
//}
public void setPhoneNumber(String phoneNumber) {
	//this.phoneNumber = phoneNumber;
}
//public String getEmail() {
	//return email;
//}
//public String setEmail(String email) {
	//this.email = email;
//}
public AddressEntries(String firstName, String lastName, String phoneNumber, String email) {
	super();
	//this.firstName = firstName;
	//this.lastName = lastName;
	//this.phoneNumber = phoneNumber;
	//this.email = email;
}
//public static AddressEntries addressFromInput() {
	//System.out.println("Please Enter Your First Name: ");
	//String firstName = input.nextLine();
	//System.out.println("Please Enter Your Last Name: ");
	//String lastName = input.nextLine();
	//System.out.println("Please Enter Your First Name: ");
	//String phoneNumber = input.nextLine();
	//System.out.println("Please Enter Your First Name: ");
	//String email = input.nextLine();
	
	//AddressEntries returnValue = new AddressEntries(firstName);
}
//}