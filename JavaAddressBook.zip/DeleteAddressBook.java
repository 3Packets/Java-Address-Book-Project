package address_book;

public class DeleteAddressBook {

}
